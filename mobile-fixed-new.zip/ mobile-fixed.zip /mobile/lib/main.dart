﻿
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

const String apiBaseUrl =
    'https://image-ai-server.almhmdq251.workers.dev';

void main() => runApp(const DotImageApp());

class DotImageApp extends StatelessWidget {
  const DotImageApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DotImage',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7057E8),
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F6FB),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final promptController = TextEditingController();
  final picker = ImagePicker();

  Uint8List? selectedImage;
  Uint8List? outputImage;
  String? selectedFileName;
  String? errorMessage;
  bool loading = false;

  Future<void> pickImage() async {
    final file = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 92,
    );

    if (file == null) return;

    setState(() {
      selectedImage = null;
      outputImage = null;
      selectedFileName = file.name;
      errorMessage = null;
    });

    selectedImage = await file.readAsBytes();

    if (mounted) setState(() {});
  }

  Future<void> generateImage() async {
    final prompt = promptController.text.trim();

    if (prompt.isEmpty) {
      setState(() => errorMessage = 'اكتب وصف الصورة أولاً.');
      return;
    }

    await _request(() async {
      final response = await http.post(
        Uri.parse('$apiBaseUrl/generate'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'prompt': prompt}),
      );

      _readImageResponse(response);
    });
  }

  Future<void> editImage() async {
    if (selectedImage == null) {
      setState(() => errorMessage = 'اختر صورة من المعرض أولاً.');
      return;
    }

    final prompt = promptController.text.trim();

    if (prompt.isEmpty) {
      setState(() => errorMessage = 'اكتب وصف التعديل المطلوب.');
      return;
    }

    await _request(() async {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$apiBaseUrl/edit'),
      );

      request.fields['prompt'] = prompt;

      request.files.add(
        http.MultipartFile.fromBytes(
          'image',
          selectedImage!,
          filename: selectedFileName ?? 'photo.jpg',
        ),
      );

      final streamed = await request.send();
      final response = await http.Response.fromStream(streamed);

      _readImageResponse(response);
    });
  }

  void _readImageResponse(http.Response response) {
    final Map<String, dynamic> body =
        jsonDecode(response.body) as Map<String, dynamic>;

    if (response.statusCode < 200 ||
        response.statusCode >= 300) {
      throw Exception(
        body['error'] ?? 'حدث خطأ في الخادم.',
      );
    }

    setState(() {
      outputImage = base64Decode(
        body['imageBase64'] as String,
      );
    });
  }

  Future<void> _request(
    Future<void> Function() action,
  ) async {
    setState(() {
      loading = true;
      errorMessage = null;
      outputImage = null;
    });

    try {
      await action();
    } catch (e) {
      setState(() {
        errorMessage = 'تعذر إكمال الطلب: $e';
      });
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  @override
  void dispose() {
    promptController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'DotImage',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          centerTitle: true,
          backgroundColor: Colors.transparent,
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF7057E8),
                    Color(0xFFB47AF0),
                  ],
                ),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'خيالك… صار صورة',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'أنشئ صورة جديدة أو ارفع صورة وعدّلها بوصفك.',
                    style: TextStyle(
                      color: Colors.white,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            const Text(
              'اكتب فكرتك',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: promptController,
              minLines: 3,
              maxLines: 5,
              decoration: InputDecoration(
                hintText:
                    'مثال: مدينة مستقبلية وقت الغروب، تصوير سينمائي واقعي...',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: loading ? null : pickImage,
              icon: const Icon(
                Icons.add_photo_alternate_outlined,
              ),
              label: Text(
                selectedFileName == null
                    ? 'اختيار صورة من الهاتف'
                    : 'الصورة المختارة: $selectedFileName',
              ),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.all(15),
              ),
            ),
            if (selectedImage != null) ...[
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.memory(
                  selectedImage!,
                  height: 190,
                  fit: BoxFit.contain,
                ),
              ),
            ],
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: loading ? null : generateImage,
              icon: const Icon(Icons.auto_awesome),
              label: const Text('إنشاء صورة'),
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.all(16),
              ),
            ),
            const SizedBox(height: 8),
            FilledButton.tonalIcon(
              onPressed: loading ? null : editImage,
              icon: const Icon(Icons.tune),
              label: const Text('تعديل الصورة المختارة'),
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.all(16),
              ),
            ),
            if (loading) ...[
              const SizedBox(height: 20),
              const Center(
                child: CircularProgressIndicator(),
              ),
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(10),
                  child: Text('جارٍ العمل على صورتك...'),
                ),
              ),
            ],
            if (errorMessage != null) ...[
              const SizedBox(height: 14),
              Text(
                errorMessage!,
                style: const TextStyle(color: Colors.red),
              ),
            ],
            if (outputImage != null) ...[
              const SizedBox(height: 24),
              const Text(
                'النتيجة',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 19,
                ),
              ),
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Image.memory(
                  outputImage!,
                  fit: BoxFit.contain,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'يمكنك حفظ الصورة باستخدام لقطة شاشة حالياً.',
                style: TextStyle(color: Colors.black54),
              ),
            ],
            const SizedBox(height: 22),
            const Text(
              'لا ترفع صوراً خاصة أو صور أشخاص دون امتلاك الحق أو الحصول على موافقتهم.',
              style: TextStyle(
                fontSize: 12,
                color: Colors.black54,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

