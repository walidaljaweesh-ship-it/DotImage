# DotImage — مشروع Android لتوليد الصور وتعديلها

مشروع بداية: تطبيق Flutter عربي + خادم Node.js وسيط يتصل بواجهة OpenAI Images API.
مفتاح API محفوظ على الخادم فقط، وليس داخل APK.

## المتطلبات
- Flutter SDK و Android SDK
- Node.js 20+
- مفتاح API صالح مع رصيد/صلاحية استخدام الصور

## تشغيل الخادم
```bash
cd server
cp .env.example .env
```
افتح `.env` وضع مفتاحك في `OPENAI_API_KEY`، ثم:
```bash
npm install
npm start
```
الخادم يستمع على المنفذ 3000.

## تشغيل تطبيق Flutter
أنشئ هيكل Flutter:
```bash
flutter create mobile
```
استبدل `mobile/pubspec.yaml` و `mobile/lib/main.dart` بالملفين المرفقين، ثم:
```bash
cd mobile
flutter pub get
flutter run
```

### عنوان الخادم
في `mobile/lib/main.dart` غيّر `apiBaseUrl`:
- محاكي Android: `http://10.0.2.2:3000`
- هاتف حقيقي: `http://IP-الكمبيوتر:3000`، مع اتصال الجهازين بنفس شبكة Wi-Fi.

أضف إذن الإنترنت في `mobile/android/app/src/main/AndroidManifest.xml` قبل وسم `<application>`:
```xml
<uses-permission android:name="android.permission.INTERNET" />
```
للتطوير المحلي عبر HTTP فقط، أضف داخل وسم `<application>`:
```xml
android:usesCleartextTraffic="true"
```
لا تستخدم HTTP أو هذا الاستثناء في الإنتاج؛ انشر الخادم عبر HTTPS.

## ما يفعله التطبيق
- إنشاء صورة من وصف نصي.
- اختيار صورة من المعرض وإرسالها لتعديلها بوصف نصي.
- عرض الصورة الناتجة داخل التطبيق.

## قبل النشر
أضف مصادقة للمستخدمين، وحدود طلبات ومعدلات استخدام، ومراقبة للتكلفة، وتخزيناً آمناً. لا تضع مفتاح API في التطبيق. استخدم الصور التي تملك حق استخدامها، واحصل على موافقة الأشخاص الظاهرين فيها.
