import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import OpenAI from 'openai';

const app = express();
const port = Number(process.env.PORT || 3000);
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = ['image/png', 'image/jpeg', 'image/webp'].includes(file.mimetype);
    cb(ok ? null : new Error('يسمح فقط بملفات PNG وJPG وWEBP.'), ok);
  }
});

app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/health', (_req, res) => res.json({ ok: true, app: 'DotImage' }));

app.post('/generate', async (req, res) => {
  try {
    const prompt = String(req.body?.prompt || '').trim();
    if (!prompt) return res.status(400).json({ error: 'اكتب وصف الصورة.' });
    if (prompt.length > 4000) return res.status(400).json({ error: 'الوصف طويل جداً.' });

    const result = await client.images.generate({
      model: 'gpt-image-2',
      prompt,
      size: '1024x1024',
      quality: 'medium',
      n: 1
    });

    const imageBase64 = result.data?.[0]?.b64_json;
    if (!imageBase64) return res.status(502).json({ error: 'لم تصل صورة من مزود الخدمة.' });
    res.json({ imageBase64, mimeType: 'image/png' });
  } catch (error) {
    console.error('Image generation failed:', error?.message || error);
    res.status(500).json({ error: 'فشل إنشاء الصورة. تحقق من مفتاح API وصلاحية الصور والرصيد.' });
  }
});

app.post('/edit', upload.single('image'), async (req, res) => {
  try {
    const prompt = String(req.body?.prompt || '').trim();
    if (!req.file) return res.status(400).json({ error: 'اختر صورة أولاً.' });
    if (!prompt) return res.status(400).json({ error: 'اكتب وصف التعديل.' });
    if (prompt.length > 4000) return res.status(400).json({ error: 'وصف التعديل طويل جداً.' });

    const imageFile = new File(
      [req.file.buffer],
      req.file.originalname || 'upload.png',
      { type: req.file.mimetype }
    );

    const result = await client.images.edit({
      model: 'gpt-image-2',
      image: imageFile,
      prompt,
      size: '1024x1024',
      quality: 'medium',
      n: 1
    });

    const imageBase64 = result.data?.[0]?.b64_json;
    if (!imageBase64) return res.status(502).json({ error: 'لم تصل صورة معدلة من مزود الخدمة.' });
    res.json({ imageBase64, mimeType: 'image/png' });
  } catch (error) {
    console.error('Image editing failed:', error?.message || error);
    res.status(500).json({ error: 'فشل تعديل الصورة. تحقق من الملف ومفتاح API وصلاحية الصور.' });
  }
});

app.use((error, _req, res, _next) => {
  res.status(400).json({ error: error.message || 'طلب غير صالح.' });
});

app.listen(port, '0.0.0.0', () => {
  console.log(`DotImage API listening on port ${port}`);
});
