# إعداد Android

داخل `mobile/android/app/src/main/AndroidManifest.xml`:
1. أضف قبل `<application>`:
   `<uses-permission android:name="android.permission.INTERNET" />`
2. للتطوير المحلي عبر HTTP فقط أضف إلى وسم `<application>`:
   `android:usesCleartextTraffic="true"`
3. استخدم HTTPS عند النشر واحذف إعداد cleartext.
